<?php
    require_once "process.php";
    if(isset($_GET['project_id'])) {
        $sql = "SELECT pic_type,image FROM projects WHERE project_id=" . $_GET['project_id'];
		$result = mysqli_query($mysqli, $sql) or die("<b>Error:</b> Problem on Retrieving Image BLOB<br/>" . mysqli_error($mysqli));
		$row = mysqli_fetch_array($result);
		header("Content-type: " . $row["pic_type"]);
        echo $row["image"];
	}
	mysqli_close($mysqli);
?>
