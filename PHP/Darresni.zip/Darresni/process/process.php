<?php
session_start();

$mysqli = new mysqli ("localhost", "root", "", "registrationdarresni") or die(mysqli_error($mysqli));
$update = false;
$subject_name='';
$subject_description='';
$subject_id = 0;
$subject_category='';
$subject_time='';
$subject_tutor='';

if(isset($_POST['save'])){
  $subject_name = $_POST['subject_name'];
  $subject_description = $_POST['subject_description'];
  $subject_category = $_POST['subject_category'];
    $subject_time = $_POST['subject_time'];
    $subject_tutor = $_POST['subject_tutor'];



  $mysqli->query("INSERT INTO subjects (subject_name, subject_description, subject_category, subject_time, subject_tutor) VALUES ('$subject_name', '$subject_description', '$subject_category', '$subject_time', '$subject_tutor')") or die($mysqli->error);
  $_SESSION['message'] = "You signed up successfully!";
  $_SESSION['msg_type'] = "primary";

  header("location: index.php");
}
if(isset($_GET['delete'])){
  $subject_id = $_GET['delete'];
  $mysqli->query("DELETE from subjects WHERE subject_id=$subject_id") or die($mysqli->error());

  $_SESSION['message'] = "Record has been deleted!";
  $_SESSION['msg_type'] = "danger";

    header("location: index.php");
}

if(isset($_GET['edit'])){
  $subject_id = $_GET['edit'];
  $update = true;
  $result = $mysqli->query("SELECT * FROM subjects WHERE subject_id=$subject_id") or die($mysqli->error());

  if(count($result)==1){
    $row = $result->fetch_array();
    $subject_name = $row['subject_name'];
    $subject_description = $row['subject_description'];
    $subject_category = $row['subject_category'];
    $subject_time = $row['subject_time'];
    $subject_tutor = $row['subject_tutor'];

  }
}
if (isset($_POST['update'])){
  $subject_id = $_POST['subject_id'];
  $subject_name = $_POST ['subject_name'];
  $subject_description = $_POST['subject_description'];
  $subject_category = $_POST['subject_category'];
  $subject_time = $_POST['subject_time'];
  $subject_tutor = $_POST['subject_tutor'];


  $mysqli->query("UPDATE subjects SET subject_name = '$subject_name', subject_description = '$subject_description', subject_category = '$subject_category', subject_time = '$subject_time', subject_tutor = '$subject_tutor' WHERE subject_id=$subject_id") or die($mysqli->error);

  $_SESSION['message'] = "Record has been updated!";
  $_SESSION['msg_type'] = "warning";

  header('location: index.php');
}
